package com.wipro.capstone.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.capstone.entity.Inventory;

public interface InventoryRepository extends JpaRepository<Inventory, Integer> {
	

}
