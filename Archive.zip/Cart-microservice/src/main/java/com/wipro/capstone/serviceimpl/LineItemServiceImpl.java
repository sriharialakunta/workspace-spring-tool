package com.wipro.capstone.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.capstone.entity.LineItem;
import com.wipro.capstone.repository.LineItemRepository;
import com.wipro.capstone.service.LineItemService;

@Service
public class LineItemServiceImpl implements LineItemService {

	@Autowired
	private LineItemRepository repository;

	@Override
	public List<LineItem> findAllLineItems() {
		return repository.findAll();
	}

	@Override
	public Optional<LineItem> searchLineItem(int id) {
		return repository.findById(id);
	}

	@Override
	public LineItem addLineItem(LineItem item) {
		return repository.save(item);
	}

	@Override
	public String deleteLineItemById(int id) {
		repository.deleteById(id);
		return "Deleted lineitem with id : " + id;
	}

	@Override
	public String deleteAllLineItems() {
		repository.deleteAll();
		return "Deleted All lineitems";
	}


	@Override
	public List<LineItem> saveAllLineItems(List<LineItem> list) {
		return repository.saveAll(list);
	}

}
