package com.wipro.capstone.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.wipro.capstone.entity.LineItem;
import com.wipro.capstone.exception.ResourceNotFoundException;
import com.wipro.capstone.service.LineItemService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/lineitem")
@Slf4j
public class LineItemController {

	@Autowired
	private LineItemService service;
	@Autowired
	private CartController cartController;
	
	@GetMapping
	public ResponseEntity<List<LineItem>> findAllLineItems() {

		List<LineItem> items = service.findAllLineItems();
		if (items.isEmpty()) {
			log.error("EMPTY LineItems");
			throw new ResourceNotFoundException("LineItems");
		}
		log.info("List Of LineItems");
		return ResponseEntity.status(HttpStatus.OK).body(items);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Optional<LineItem>> searchLineItem(@PathVariable("id") int id) {

		Optional<LineItem> item = service.searchLineItem(id);
		if (item.isEmpty()) {
			log.error("LineItem with id : " + id + " not found");
			throw new ResourceNotFoundException("LineItem with id : " + id);
		}
		log.info("Details Of LineItem " + id);
		return ResponseEntity.status(HttpStatus.OK).body(item);
	}

	@PostMapping
	public ResponseEntity<LineItem> addLineItem(@RequestBody LineItem item, UriComponentsBuilder ucBuilder) {

		log.info("Creating New LineItem ");
		cartController.searchCart(item.getCart().getCartId());
		LineItem newItem = service.addLineItem(item);
		return ResponseEntity.status(HttpStatus.CREATED)
				.location(ucBuilder.path("/api/lineitem/{id}").buildAndExpand(newItem.getItemId()).toUri())
				.body(newItem);
	}

	@PutMapping("/{id}")
	public ResponseEntity<LineItem> updateLineItem(@PathVariable int id,@RequestBody LineItem item, UriComponentsBuilder ucBuilder) {
		log.info("Updating Cart Details of id :" + item.getItemId());
		item.setItemId(
		searchLineItem(id).getBody().get().getItemId());
		LineItem newLineItem = service.addLineItem(item);
		return ResponseEntity.status(HttpStatus.CREATED)
				.location(ucBuilder.path("/api/lineitem/{id}").buildAndExpand(newLineItem.getItemId()).toUri())
				.body(newLineItem);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteteLineItem(@PathVariable("id") int id) {

		log.info("Fetching & Deleting LineItem with id " + id);
		if (!searchLineItem(id).hasBody()) {
			log.error("Unable to delete. Cart with this id " + id + " not found");
			throw new ResourceNotFoundException("Unable to delete. Cart with this id " + id);
		}
		log.info("Deleted Cart with this id " + id);
		return ResponseEntity.status(HttpStatus.OK).body(service.deleteLineItemById(id));

	}

	@DeleteMapping
	public ResponseEntity<String> deleteteAllLineItems() {

		log.info("Deleting All LineItem");
		return ResponseEntity.status(HttpStatus.OK).body(service.deleteAllLineItems());
	}

}
