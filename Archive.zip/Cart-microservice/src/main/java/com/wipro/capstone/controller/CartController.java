package com.wipro.capstone.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.wipro.capstone.entity.Cart;
import com.wipro.capstone.exception.ResourceNotFoundException;
import com.wipro.capstone.service.CartService;
import com.wipro.capstone.service.LineItemService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/cart")
@Slf4j
public class CartController {

	@Autowired
	private CartService service;
	
	@Autowired
	private LineItemService itemService;
	
	@GetMapping
	public ResponseEntity<List<Cart>> findAllCarts() {

//		List<Cart> carts = service.findAllCarts();
//		return carts.isEmpty() ? throw new ResourceNotFoundException("Cart") :
//			ResponseEntity.ok(carts); 
//		if (carts.isEmpty()) {
//			log.error("EMPTY Carts List");
//			throw new ResourceNotFoundException("Cart");
//		}
		log.info("List Of Cart");
		return ResponseEntity.status(HttpStatus.OK).body(service.findAllCarts());
	}

	@GetMapping("/{id}")
	public ResponseEntity<Optional<Cart>> searchCart(@PathVariable("id") int id) {

//		Optional<Cart> cart = service.searchCart(id);
//		if (cart.isEmpty()) {
//			log.error("Cart with id : " + id + " not found");
//			throw new ResourceNotFoundException("Cart with id : " + id);
//		}
		log.info("Details Of Cart " + id);
		return ResponseEntity.status(HttpStatus.OK).body(service.searchCart(id));
	}

	@PostMapping
	public ResponseEntity<Cart> addCart(@RequestBody Cart cart, UriComponentsBuilder ucBuilder) {

		log.info("Creating New Cart ");
		Cart newcart = service.addCart(cart);
		if(cart.getLineItems() != null) {
			cart.getLineItems().stream().forEach(x->x.setCart(newcart));
			itemService.saveAllLineItems(cart.getLineItems());
//			cart.getItem().stream().forEach(x->x.setCart(newcart));
//			itemService.saveAllLineItems(cart.getItem());
	}
		return ResponseEntity.status(HttpStatus.CREATED)
				.location(ucBuilder.path("/api/cart/{id}").buildAndExpand(newcart.getCartId()).toUri())
				.body(newcart);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Cart> updateCart(@PathVariable int id,@RequestBody Cart cart, UriComponentsBuilder ucBuilder) {
		log.info("Updating Cart Details of id :" +id);
		cart.setCartId(
		searchCart(id).getBody().get().getCartId());
		Cart newcart = service.addCart(cart);
		return ResponseEntity.status(HttpStatus.CREATED)
				.location(ucBuilder.path("/api/cart/{id}").buildAndExpand(newcart.getCartId()).toUri())
				.body(newcart);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> emptyCart(@PathVariable("id") int id) {

//		log.info("Fetching & Deleting Cart with id " + id);
//		if (!searchCart(id).hasBody()) {
//			log.error("Unable to delete. Cart with this id " + id + " not found");
//			throw new ResourceNotFoundException("Unable to delete. Cart with this id " + id);
//		}
		log.info("Deleted Cart with this id " + id);
		return ResponseEntity.status(HttpStatus.OK).body(service.deleteCartById(id));

	}

	@DeleteMapping
	public ResponseEntity<String> emptyAllCart() {

		log.info("Deleting All Carts");
		return ResponseEntity.status(HttpStatus.OK).body(service.deleteAllCarts());
	}

}
