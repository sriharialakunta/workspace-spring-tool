package our.foundation.bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OurBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(OurBankApplication.class, args);
	}

}
